﻿using System.ComponentModel.DataAnnotations;

namespace Lap4.Models
{
    public class User
    {
        [Display(Name = "mã sinh viên")]
        [Required(ErrorMessage = "không được để trống")]
        public string? Id { get; set; }
        [Display(Name = "tên sinh viên")]
        [Required(ErrorMessage = "không được để trống")]
        [MaxLength (20, ErrorMessage = "Tài khoản từ 6 - 20 ký tự")]
        [MinLength (6, ErrorMessage = "Tài khoản từ 6 - 20 ký tự")]
        public string? UserName { get; set; }
        [Display(Name = "mật khẩu")]
        [Required(ErrorMessage = "không được để trống")]
        [MaxLength(10, ErrorMessage = "Tài khoản từ 6 - 10 ký tự")]
        [MinLength(6, ErrorMessage = "Tài khoản từ 6 - 10 ký tự")]
        public string? Password { get; set; }
        [Display(Name = "điện thoại ")]
        [Required(ErrorMessage = "không được để trống")]
        public string? Phone {  get; set; }
        [Display(Name = "email")]
        [Required(ErrorMessage = "không được để trống")]
        [DataType(DataType.EmailAddress, ErrorMessage = "sai định dạng email")]
        public string? Email { get; set; }

    }
}
