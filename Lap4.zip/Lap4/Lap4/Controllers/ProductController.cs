﻿using Lap4.Models;
using Microsoft.AspNetCore.Mvc;

namespace Lap4.Controllers
{
    public class ProductController : Controller
    {
        static List<Product> products = new List<Product>() { }; 
        public IActionResult Index()
        {
            return View(products);
        }
        public IActionResult Details()
        {
            return View();
        }

        public IActionResult Save(Product product)
        {
            products.Add(product);
            return RedirectToAction("Index");
        }

        public IActionResult Delete(Product product)
        {
            var deleteProduct = products.FirstOrDefault(p  => p.Id == product.Id);
            if (deleteProduct != null)
            {
                products.Remove(deleteProduct);
            }
            return RedirectToAction("Index");
        }
        public IActionResult Edit(int id)
        {
            var editProduct = products.FirstOrDefault(x => x.Id == id);
            if (editProduct != null)
            {
                return View(editProduct);
            }
            return RedirectToAction("Index");
        }

        [HttpPost]
        public IActionResult Edit(Product UpdateProduct)
        {
            var EditProduct = products.FirstOrDefault(x => x.Id == UpdateProduct.Id);
            if (EditProduct != null)
            {
                EditProduct.Name = UpdateProduct.Name;
                EditProduct.Price = UpdateProduct.Price;
            }
            return RedirectToAction("Index");
        }

    }
}
