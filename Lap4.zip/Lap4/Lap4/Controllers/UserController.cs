﻿using Lap4.Models;
using Microsoft.AspNetCore.Mvc;

namespace Lap4.Controllers
{
    public class UserController : Controller
    {
        static List<User> users = new List<User>() { };
        public IActionResult Index()
        {
            return View(users);
        }

        public IActionResult Add()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Add(User user)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    users.Add(user);
                    return RedirectToAction("Index");
                }
            }
            catch (Exception ex)
            {
                ModelState.AddModelError(String.Empty, ex.Message);
            }
            return View(user);
        }

        public IActionResult Delete(User user)
        {
            var DeleteUser = users.FirstOrDefault(x => x.Id == user.Id);
            if (DeleteUser != null)
            {
                users.Remove(DeleteUser);
            }
            return RedirectToAction("Index");
        }

        public IActionResult Edit(string id)
        {
            var EditUser = users.FirstOrDefault(x => x.Id == id);
            if (EditUser != null)
            {
                return View(EditUser);
            }
            return RedirectToAction("Index");
        }
        [HttpPost]
        public IActionResult Edit(User UpdateUser)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    var EditUser = users.FirstOrDefault(x => x.Id == UpdateUser.Id);
                    if (EditUser != null)
                    {
                        EditUser.UserName = UpdateUser.UserName;
                        EditUser.Password = UpdateUser.Password;
                        EditUser.Phone = UpdateUser.Phone;
                        EditUser.Email = UpdateUser.Email;
                    }
                    return RedirectToAction("Index");
                }
            }
            catch (Exception ex)
            {
                ModelState.AddModelError(String.Empty, ex.Message);
            }
            return View(UpdateUser);
        }
    }
}
